package com.xxx.member.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxx.common.utils.PageUtils;
import com.xxx.member.entity.MemberEntity;

import java.util.List;
import java.util.Map;

/**
 * 会员-会员表
 *
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:33:30
 */
public interface MemberService extends IService<MemberEntity> {

    PageUtils queryPage(Map<String, Object> params);
    public List<Map<String, Object>> countByDateTime(String beginTime, String endTime);
    public MemberEntity login(String username,String password);
}

