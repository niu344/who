package com.xxx.member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UMemberApplicationTests {

    @Test
    void contextLoads() {
    }

}
