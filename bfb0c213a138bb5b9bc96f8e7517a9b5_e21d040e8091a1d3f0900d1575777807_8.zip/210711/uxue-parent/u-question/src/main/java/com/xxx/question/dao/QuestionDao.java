package com.xxx.question.dao;

import com.xxx.question.entity.QuestionEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:31:10
 */
@Mapper
public interface QuestionDao extends BaseMapper<QuestionEntity> {
	
}
