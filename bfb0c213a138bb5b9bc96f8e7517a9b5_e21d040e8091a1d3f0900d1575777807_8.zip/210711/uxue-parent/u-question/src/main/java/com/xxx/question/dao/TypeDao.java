package com.xxx.question.dao;

import com.xxx.question.entity.TypeEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 题目-题目类型表
 * 
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:31:10
 */
@Mapper
public interface TypeDao extends BaseMapper<TypeEntity> {
	
}
