package com.xxx.question.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxx.common.utils.PageUtils;
import com.xxx.question.entity.QuestionEntity;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * 
 *
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:31:10
 */
public interface QuestionService extends IService<QuestionEntity> {

    PageUtils queryPage(Map<String, Object> params);
    //导入
    public Map importExcel(MultipartFile file);
    //导出
    public Workbook exportExcel();
    public List<Map<String, Object>> countTypeQuestion();

}

