package com.xxx.context;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UContextApplicationTests {

    @Test
    void contextLoads() {
    }

}
