package com.xxx.context.dao;

import com.xxx.context.entity.NewsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 内容-资讯表
 * 
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:25:11
 */
@Mapper
public interface NewsDao extends BaseMapper<NewsEntity> {
	
}
