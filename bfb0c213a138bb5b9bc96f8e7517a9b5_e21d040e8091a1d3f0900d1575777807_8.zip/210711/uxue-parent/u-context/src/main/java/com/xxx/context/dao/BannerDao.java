package com.xxx.context.dao;

import com.xxx.context.entity.BannerEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 内容-横幅广告表
 * 
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:25:11
 */
@Mapper
public interface BannerDao extends BaseMapper<BannerEntity> {
	
}
