package com.xxx.context.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxx.common.utils.PageUtils;
import com.xxx.context.entity.NewsEntity;

import java.util.Map;

/**
 * 内容-资讯表
 *
 * @author platov
 * @email platov@admin.com
 * @date 2024-10-12 09:25:11
 */
public interface NewsService extends IService<NewsEntity> {

    PageUtils queryPage(Map<String, Object> params);
}

