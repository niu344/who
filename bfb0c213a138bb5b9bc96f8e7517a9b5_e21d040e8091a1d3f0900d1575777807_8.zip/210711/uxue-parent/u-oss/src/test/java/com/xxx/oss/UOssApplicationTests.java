package com.xxx.oss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UOssApplicationTests {

    @Test
    void contextLoads() {
    }

}
